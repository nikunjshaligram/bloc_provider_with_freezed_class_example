package com.example.bloc_provider_with_freezed_class_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
